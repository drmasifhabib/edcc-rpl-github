\
#pragma once

/* Select RPL Classic */
#undef NETSTACK_CONF_ROUTING
#define NETSTACK_CONF_ROUTING rpl_classic_driver

/* Select objective function (EDCC) */
#undef RPL_CONF_OF
#define RPL_CONF_OF rpl_of_edcc

/* Enable link stats (ETX) */
#undef LINK_STATS_CONF_ENABLED
#define LINK_STATS_CONF_ENABLED 1

/* Reduce log noise */
#undef LOG_CONF_LEVEL_RPL
#define LOG_CONF_LEVEL_RPL LOG_LEVEL_WARN
