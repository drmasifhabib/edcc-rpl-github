\
#include "contiki.h"
#include "net/ipv6/simple-udp.h"
#include "net/routing/rpl-classic/rpl.h"
#include "sys/log.h"
#include <stdio.h>

#define LOG_MODULE "EDCC-SINK"
#define LOG_LEVEL LOG_LEVEL_INFO

#ifndef APP_PORT
#define APP_PORT 30010
#endif

static struct simple_udp_connection udp;

static void
udp_rx(struct simple_udp_connection *c,
       const uip_ipaddr_t *sender_addr, uint16_t sender_port,
       const uip_ipaddr_t *receiver_addr, uint16_t receiver_port,
       const uint8_t *data, uint16_t datalen)
{
  (void)c; (void)sender_port; (void)receiver_addr; (void)receiver_port;
  LOG_INFO("RX from ");
  LOG_INFO_6ADDR(sender_addr);
  LOG_INFO_(": %u bytes\n", (unsigned)datalen);
}

PROCESS(edcc_sink_process, "EDCC sink");
AUTOSTART_PROCESSES(&edcc_sink_process);

PROCESS_THREAD(edcc_sink_process, ev, data)
{
  (void)ev; (void)data;
  PROCESS_BEGIN();

  simple_udp_register(&udp, APP_PORT, NULL, APP_PORT, udp_rx);

  /* Start as RPL root */
  rpl_dag_t *dag = rpl_set_root(RPL_DEFAULT_INSTANCE, (uip_ipaddr_t *)&uip_ds6_if.addr_list[0].ipaddr);
  if(dag != NULL) {
    rpl_set_prefix(dag, &uip_ds6_if.addr_list[0].ipaddr, 64);
    LOG_INFO("RPL root started\n");
  } else {
    LOG_ERR("Failed to start RPL root\n");
  }

  while(1) {
    PROCESS_WAIT_EVENT();
  }

  PROCESS_END();
}
