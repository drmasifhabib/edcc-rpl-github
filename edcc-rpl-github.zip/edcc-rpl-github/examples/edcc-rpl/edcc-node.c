\
#include "contiki.h"
#include "net/ipv6/simple-udp.h"
#include "net/routing/rpl-classic/rpl.h"
#include "sys/log.h"
#include "os/net/routing/rpl-classic/edcc-childreg.h"
#include "os/net/routing/rpl-classic/edcc-delayprobe.h"
#include "os/net/routing/rpl-classic/edcc-energy.h"
#include <stdio.h>
#include <string.h>

#define LOG_MODULE "EDCC-NODE"
#define LOG_LEVEL LOG_LEVEL_INFO

#ifndef APP_PORT
#define APP_PORT 30010
#endif

#ifndef SEND_INTERVAL_SEC
#define SEND_INTERVAL_SEC 30
#endif

static struct simple_udp_connection udp;
static uip_ipaddr_t sink_ip;

/* Very small payload */
typedef struct __attribute__((packed)) {
  uint16_t seq;
  uint32_t t;
} app_msg_t;

PROCESS(edcc_node_process, "EDCC node");
AUTOSTART_PROCESSES(&edcc_node_process);

static void
udp_rx(struct simple_udp_connection *c,
       const uip_ipaddr_t *sender_addr, uint16_t sender_port,
       const uip_ipaddr_t *receiver_addr, uint16_t receiver_port,
       const uint8_t *data, uint16_t datalen)
{
  (void)c; (void)sender_addr; (void)sender_port; (void)receiver_addr; (void)receiver_port; (void)data; (void)datalen;
}

PROCESS_THREAD(edcc_node_process, ev, data)
{
  static struct etimer periodic;
  static uint16_t seq;
  (void)ev; (void)data;

  PROCESS_BEGIN();

  simple_udp_register(&udp, APP_PORT, NULL, APP_PORT, udp_rx);

  /* Init EDCC auxiliary modules */
  edcc_energy_init();
  edcc_childreg_init();
  edcc_delayprobe_init();

  /* Sink = fd00::1 by convention in Cooja */
  uip_ip6addr(&sink_ip, 0xfd00,0,0,0,0,0,0,1);

  etimer_set(&periodic, SEND_INTERVAL_SEC * CLOCK_SECOND);
  seq = 1;

  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&periodic));
    etimer_reset(&periodic);

    app_msg_t m;
    m.seq = seq++;
    m.t = (uint32_t)clock_seconds();
    simple_udp_sendto(&udp, &m, sizeof(m), &sink_ip);

    LOG_INFO("TX seq=%u to sink, RE=%.2f CC=%u\n",
             (unsigned)m.seq,
             (double)edcc_energy_residual_ratio(),
             (unsigned)edcc_childreg_get_child_count());
  }

  PROCESS_END();
}
