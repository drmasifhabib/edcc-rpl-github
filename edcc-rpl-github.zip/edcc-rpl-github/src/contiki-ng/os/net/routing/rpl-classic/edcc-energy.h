\
#pragma once
#include "contiki.h"

/* Simple energy estimator (Cooja/Energest).
 * Returns residual energy ratio in [0,1] and as Q8 (0..255).
 */
void edcc_energy_init(void);
float edcc_energy_residual_ratio(void);
uint8_t edcc_energy_residual_q8(void);
