\
#include "edcc-energy.h"
#include "sys/energest.h"
#include <stdio.h>

/* Default Sky mote-ish current draw (mA) and voltage (V)
 * You may adjust these to match your platform profile.
 */
#ifndef EDCC_VOLTAGE_V
#define EDCC_VOLTAGE_V 3.0f
#endif
#ifndef EDCC_I_CPU_MA
#define EDCC_I_CPU_MA 1.8f
#endif
#ifndef EDCC_I_LPM_MA
#define EDCC_I_LPM_MA 0.0545f
#endif
#ifndef EDCC_I_TX_MA
#define EDCC_I_TX_MA 17.4f
#endif
#ifndef EDCC_I_RX_MA
#define EDCC_I_RX_MA 18.8f
#endif

/* Initial energy budget (mJ) for normalization; pick a value large enough for the sim time */
#ifndef EDCC_E0_MJ
#define EDCC_E0_MJ 10000.0f
#endif

static float e0_mj;

void
edcc_energy_init(void)
{
  energest_init();
  e0_mj = EDCC_E0_MJ;
}

static float
ticks_to_seconds(uint64_t ticks)
{
#ifdef ENERGEST_SECOND
  return (float)ticks / (float)ENERGEST_SECOND;
#else
  return (float)ticks / (float)CLOCK_SECOND;
#endif
}

static float
energy_mj_from_time(float seconds, float current_ma)
{
  /* P = V * I; E = P * t; where V in V, I in mA => P in mW; E in mJ */
  float power_mw = EDCC_VOLTAGE_V * current_ma;
  return power_mw * seconds;
}

float
edcc_energy_residual_ratio(void)
{
  energest_flush();

  float t_cpu = ticks_to_seconds(energest_type_time(ENERGEST_TYPE_CPU));
  float t_lpm = ticks_to_seconds(energest_type_time(ENERGEST_TYPE_LPM));
  float t_tx  = ticks_to_seconds(energest_type_time(ENERGEST_TYPE_TRANSMIT));
  float t_rx  = ticks_to_seconds(energest_type_time(ENERGEST_TYPE_LISTEN));

  float e_mj = 0.0f;
  e_mj += energy_mj_from_time(t_cpu, EDCC_I_CPU_MA);
  e_mj += energy_mj_from_time(t_lpm, EDCC_I_LPM_MA);
  e_mj += energy_mj_from_time(t_tx,  EDCC_I_TX_MA);
  e_mj += energy_mj_from_time(t_rx,  EDCC_I_RX_MA);

  float rem = 1.0f - (e_mj / e0_mj);
  if(rem < 0.0f) rem = 0.0f;
  if(rem > 1.0f) rem = 1.0f;
  return rem;
}

uint8_t
edcc_energy_residual_q8(void)
{
  float r = edcc_energy_residual_ratio();
  int v = (int)(r * 255.0f + 0.5f);
  if(v < 0) v = 0;
  if(v > 255) v = 255;
  return (uint8_t)v;
}
