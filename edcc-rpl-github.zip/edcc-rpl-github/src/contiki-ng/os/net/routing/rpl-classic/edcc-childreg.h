\
#pragma once
#include "contiki.h"
#include "net/ipv6/uip.h"

/* Child registration protocol:
 * - children periodically send JOIN to their preferred parent
 * - send LEAVE when switching (best effort)
 * - parents maintain a soft-state table and advertise current child_count in DIO
 */
void edcc_childreg_init(void);
uint8_t edcc_childreg_get_child_count(void); /* number of registered children */

PROCESS_NAME(edcc_childreg_process);
