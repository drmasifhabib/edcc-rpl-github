\
#pragma once
#include "contiki.h"

/* EDCC delay probing:
 * - Periodically send small UDP probes to neighbors
 * - Measure RTT (send->echo) and feed into edcc_neighbor_delay_sample()
 */
void edcc_delayprobe_init(void);
PROCESS_NAME(edcc_delayprobe_process);
