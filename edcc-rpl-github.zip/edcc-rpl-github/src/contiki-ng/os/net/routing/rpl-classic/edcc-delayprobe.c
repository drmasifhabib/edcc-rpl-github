\
#include "edcc-delayprobe.h"
#include "edcc-neighbor.h"
#include "net/ipv6/simple-udp.h"
#include "net/ipv6/uip-ds6-nbr.h"
#include "sys/log.h"
#include <string.h>
#include <stdio.h>

#define LOG_MODULE "EDCC-DLY"
#define LOG_LEVEL LOG_LEVEL_INFO

#ifndef EDCC_DELAYPROBE_PORT
#define EDCC_DELAYPROBE_PORT 30002
#endif

#ifndef EDCC_DELAYPROBE_PERIOD_SEC
#define EDCC_DELAYPROBE_PERIOD_SEC 15
#endif

#ifndef EDCC_DELAYPROBE_MAX_INFLIGHT
#define EDCC_DELAYPROBE_MAX_INFLIGHT 32
#endif

typedef struct {
  uip_ipaddr_t nbr;
  uint16_t seq;
  clock_time_t t0;
  uint8_t used;
} inflight_t;

static inflight_t inflight[EDCC_DELAYPROBE_MAX_INFLIGHT];
static struct simple_udp_connection udp;
static uint16_t seqno;

typedef enum { MSG_PROBE = 1, MSG_ECHO = 2 } msg_type_t;

typedef struct __attribute__((packed)) {
  uint8_t type;
  uint16_t seq;
  uint32_t t0_ticks;
} probe_msg_t;

static int
inflight_find(const uip_ipaddr_t *nbr, uint16_t seq)
{
  for(int i=0;i<EDCC_DELAYPROBE_MAX_INFLIGHT;i++) {
    if(inflight[i].used && inflight[i].seq == seq && uip_ipaddr_cmp(&inflight[i].nbr, nbr)) return i;
  }
  return -1;
}

static int
inflight_alloc(const uip_ipaddr_t *nbr, uint16_t seq, clock_time_t t0)
{
  for(int i=0;i<EDCC_DELAYPROBE_MAX_INFLIGHT;i++) {
    if(!inflight[i].used) {
      inflight[i].used = 1;
      inflight[i].seq = seq;
      inflight[i].t0 = t0;
      uip_ipaddr_copy(&inflight[i].nbr, nbr);
      return i;
    }
  }
  return -1;
}

static void
inflight_free(int idx)
{
  if(idx < 0 || idx >= EDCC_DELAYPROBE_MAX_INFLIGHT) return;
  inflight[idx].used = 0;
}

static void
udp_rx(struct simple_udp_connection *c,
       const uip_ipaddr_t *sender_addr, uint16_t sender_port,
       const uip_ipaddr_t *receiver_addr, uint16_t receiver_port,
       const uint8_t *data, uint16_t datalen)
{
  (void)c; (void)sender_port; (void)receiver_addr; (void)receiver_port;
  if(datalen < sizeof(probe_msg_t)) return;

  probe_msg_t m;
  memcpy(&m, data, sizeof(m));

  if(m.type == MSG_PROBE) {
    /* Echo back */
    m.type = MSG_ECHO;
    simple_udp_sendto(&udp, &m, sizeof(m), sender_addr);
  } else if(m.type == MSG_ECHO) {
    int idx = inflight_find(sender_addr, m.seq);
    if(idx >= 0) {
      clock_time_t t1 = clock_time();
      clock_time_t dt = t1 - inflight[idx].t0;
      uint16_t rtt_ms = (uint16_t)((1000UL * (uint32_t)dt) / CLOCK_SECOND);
      edcc_neighbor_delay_sample(sender_addr, rtt_ms);
      inflight_free(idx);
    }
  }
}

PROCESS(edcc_delayprobe_process, "EDCC delay probe");

void
edcc_delayprobe_init(void)
{
  memset(inflight, 0, sizeof(inflight));
  seqno = 1;
  simple_udp_register(&udp, EDCC_DELAYPROBE_PORT, NULL, EDCC_DELAYPROBE_PORT, udp_rx);
  process_start(&edcc_delayprobe_process, NULL);
}

PROCESS_THREAD(edcc_delayprobe_process, ev, data)
{
  static struct etimer periodic;
  (void)ev; (void)data;

  etimer_set(&periodic, EDCC_DELAYPROBE_PERIOD_SEC * CLOCK_SECOND);
  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&periodic));
    etimer_reset(&periodic);

    /* Probe a few neighbors from neighbor cache */
    int sent = 0;
    for(uip_ds6_nbr_t *nbr = uip_ds6_nbr_head();
        nbr != NULL && sent < 3;
        nbr = uip_ds6_nbr_next(nbr)) {

      if(!nbr->isrouter) continue; /* likely candidate parents */

      probe_msg_t m;
      m.type = MSG_PROBE;
      m.seq = seqno++;
      m.t0_ticks = (uint32_t)clock_time();

      clock_time_t t0 = clock_time();
      if(inflight_alloc(&nbr->ipaddr, m.seq, t0) >= 0) {
        simple_udp_sendto(&udp, &m, sizeof(m), &nbr->ipaddr);
        sent++;
      }
    }
  }
  PROCESS_END();
}
