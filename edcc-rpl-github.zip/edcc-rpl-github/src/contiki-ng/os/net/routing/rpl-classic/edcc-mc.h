\
#pragma once
#include "contiki.h"
#include "net/ipv6/uip.h"
#include "net/routing/rpl-classic/rpl.h"

/* Encode EDCC data into RPL Metric Container in DIO.
 * Format (very small, local):
 *  [type=RPL_DAG_MC_EDCC][len=2][child_count][residual_energy_q8]
 */
int edcc_mc_write(uint8_t *buf, int buf_len, uint8_t child_count, uint8_t residual_energy_q8);

/* Parse EDCC container; returns 1 if parsed and updated neighbor table, else 0 */
int edcc_mc_parse_and_update(const uip_ipaddr_t *from, const uint8_t *buf, int buf_len);
