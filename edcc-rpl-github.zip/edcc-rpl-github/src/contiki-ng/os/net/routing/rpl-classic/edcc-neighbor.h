\
#pragma once
#include "contiki.h"
#include "net/ipv6/uip.h"
#include "net/routing/rpl-classic/rpl.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Store EDCC per-neighbor attributes (advertised + locally measured) */
void edcc_neighbor_init(void);

/* Called when a DIO metric container with EDCC option is received from neighbor */
void edcc_neighbor_update_from_dio(const uip_ipaddr_t *from,
                                  uint8_t child_count,
                                  uint8_t residual_energy_q8);

/* Delay estimator */
void edcc_neighbor_delay_sample(const uip_ipaddr_t *nbr, uint16_t rtt_ms);
float edcc_neighbor_get_delay_ms(const uip_ipaddr_t *nbr);

/* Advertised values getters (defaults if unknown) */
uint8_t edcc_neighbor_get_child_count(const uip_ipaddr_t *nbr);
float edcc_neighbor_get_residual_energy(const uip_ipaddr_t *nbr); /* 0..1 */

/* Normalization helpers (computed per decision round) */
void edcc_neighbor_normalization_begin(void);
void edcc_neighbor_normalization_observe(const uip_ipaddr_t *nbr,
                                        float etx, float delay_ms,
                                        float cc_penalized, float residual_energy);
void edcc_neighbor_normalization_end(void);
float edcc_norm_etx(float etx);
float edcc_norm_delay(float delay_ms);
float edcc_norm_cc(float cc_penalized);
float edcc_norm_energy_penalty(float residual_energy);

#ifdef __cplusplus
}
#endif
