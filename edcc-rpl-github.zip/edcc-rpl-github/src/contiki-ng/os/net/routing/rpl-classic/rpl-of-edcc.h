\
#pragma once
/*
 * EDCC-RPL Objective Function (ETX + Delay + Child Count + Residual Energy)
 *
 * This is a research reference implementation intended for reproducibility in Cooja.
 * It follows the paper's algorithmic steps (ETX normalization, child-count penalty,
 * delay sliding window, optional weight adaptation, residual-energy penalty).
 *
 * Tunables:
 *  - EDCC_ALPHA1/2/3/4: weights
 *  - EDCC_TAU_CC: child-count threshold τ_CC
 *  - EDCC_LAMBDA_CC: penalty slope λ_CC
 *  - EDCC_THETA: hysteresis margin θ
 *  - EDCC_DELAY_W: sliding window size W
 */
#include "contiki.h"
#include "net/routing/rpl-classic/rpl.h"

/* Default parameters (can be overridden with -D at compile time) */
#ifndef EDCC_ALPHA1
#define EDCC_ALPHA1 0.34f
#endif
#ifndef EDCC_ALPHA2
#define EDCC_ALPHA2 0.33f
#endif
#ifndef EDCC_ALPHA3
#define EDCC_ALPHA3 0.33f
#endif
#ifndef EDCC_ALPHA4
#define EDCC_ALPHA4 0.15f
#endif

#ifndef EDCC_TAU_CC
#define EDCC_TAU_CC 6
#endif
#ifndef EDCC_LAMBDA_CC
#define EDCC_LAMBDA_CC 0.15f
#endif
#ifndef EDCC_THETA
#define EDCC_THETA 0.05f
#endif

#ifndef EDCC_DELAY_W
#define EDCC_DELAY_W 5
#endif

/* Metric container option type for EDCC (experimental / local use) */
#ifndef RPL_DAG_MC_EDCC
#define RPL_DAG_MC_EDCC 0xEE /* non-standard / local */
#endif

/* Exported objective function instance */
extern rpl_of_t rpl_of_edcc;

/* Helper getters used by the OF */
uint8_t edcc_get_advertised_child_count(const rpl_parent_t *p);
float edcc_get_advertised_residual_energy(const rpl_parent_t *p);
float edcc_get_delay_estimate_norm(const rpl_parent_t *p);

