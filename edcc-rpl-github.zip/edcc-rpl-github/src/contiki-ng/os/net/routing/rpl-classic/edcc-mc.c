\
#include "edcc-mc.h"
#include "edcc-neighbor.h"
#include "rpl-of-edcc.h"
#include <string.h>

int
edcc_mc_write(uint8_t *buf, int buf_len, uint8_t child_count, uint8_t residual_energy_q8)
{
  if(buf_len < 4) return 0;
  buf[0] = RPL_DAG_MC_EDCC;
  buf[1] = 2;
  buf[2] = child_count;
  buf[3] = residual_energy_q8;
  return 4;
}

int
edcc_mc_parse_and_update(const uip_ipaddr_t *from, const uint8_t *buf, int buf_len)
{
  int i = 0;
  while(i + 2 <= buf_len) {
    uint8_t type = buf[i];
    uint8_t len  = buf[i+1];
    if(i + 2 + len > buf_len) break;

    if(type == RPL_DAG_MC_EDCC && len >= 2) {
      uint8_t cc = buf[i+2];
      uint8_t re = buf[i+3];
      edcc_neighbor_update_from_dio(from, cc, re);
      return 1;
    }
    i += 2 + len;
  }
  return 0;
}
