\
#include "edcc-childreg.h"
#include "net/routing/rpl-classic/rpl.h"
#include "net/ipv6/simple-udp.h"
#include "sys/ctimer.h"
#include "sys/log.h"
#include "lib/list.h"
#include "lib/memb.h"
#include <string.h>

#define LOG_MODULE "EDCC-CC"
#define LOG_LEVEL LOG_LEVEL_INFO

#ifndef EDCC_CHILDREG_PORT
#define EDCC_CHILDREG_PORT 30001
#endif

#ifndef EDCC_CHILDREG_KEEPALIVE_SEC
#define EDCC_CHILDREG_KEEPALIVE_SEC 60
#endif

#ifndef EDCC_CHILDREG_TIMEOUT_SEC
#define EDCC_CHILDREG_TIMEOUT_SEC 180
#endif

#ifndef EDCC_CHILDREG_MAX_CHILDREN
#define EDCC_CHILDREG_MAX_CHILDREN 64
#endif

typedef enum { MSG_JOIN = 1, MSG_LEAVE = 2 } msg_type_t;

typedef struct {
  uip_ipaddr_t child;
  uint32_t last_seen;
} child_entry_t;

MEMB(child_memb, child_entry_t, EDCC_CHILDREG_MAX_CHILDREN);
LIST(child_list);

static struct simple_udp_connection udp;
static uip_ipaddr_t last_parent;
static uint8_t have_last_parent;

static child_entry_t *
find_child(const uip_ipaddr_t *addr)
{
  child_entry_t *e;
  for(e = list_head(child_list); e != NULL; e = list_item_next(e)) {
    if(uip_ipaddr_cmp(&e->child, addr)) return e;
  }
  return NULL;
}

static void
purge_expired(void)
{
  child_entry_t *e = list_head(child_list);
  child_entry_t *next;
  uint32_t now = clock_seconds();

  while(e != NULL) {
    next = list_item_next(e);
    if(now - e->last_seen > EDCC_CHILDREG_TIMEOUT_SEC) {
      list_remove(child_list, e);
      memb_free(&child_memb, e);
    }
    e = next;
  }
}

static void
udp_rx(struct simple_udp_connection *c,
       const uip_ipaddr_t *sender_addr, uint16_t sender_port,
       const uip_ipaddr_t *receiver_addr, uint16_t receiver_port,
       const uint8_t *data, uint16_t datalen)
{
  (void)c; (void)sender_port; (void)receiver_addr; (void)receiver_port;
  if(datalen < 1) return;

  purge_expired();

  uint8_t t = data[0];
  if(t == MSG_JOIN) {
    child_entry_t *e = find_child(sender_addr);
    if(e == NULL) {
      e = memb_alloc(&child_memb);
      if(e == NULL) return;
      memset(e, 0, sizeof(*e));
      uip_ipaddr_copy(&e->child, sender_addr);
      list_add(child_list, e);
    }
    e->last_seen = clock_seconds();
  } else if(t == MSG_LEAVE) {
    child_entry_t *e = find_child(sender_addr);
    if(e != NULL) {
      list_remove(child_list, e);
      memb_free(&child_memb, e);
    }
  }
}

static void
send_msg(const uip_ipaddr_t *parent, msg_type_t t)
{
  uint8_t buf[1];
  buf[0] = (uint8_t)t;
  simple_udp_sendto(&udp, buf, sizeof(buf), parent);
}

PROCESS(edcc_childreg_process, "EDCC child registration");

void
edcc_childreg_init(void)
{
  memb_init(&child_memb);
  list_init(child_list);
  have_last_parent = 0;
  simple_udp_register(&udp, EDCC_CHILDREG_PORT, NULL, EDCC_CHILDREG_PORT, udp_rx);
  process_start(&edcc_childreg_process, NULL);
}

uint8_t
edcc_childreg_get_child_count(void)
{
  purge_expired();
  uint8_t count = 0;
  child_entry_t *e;
  for(e = list_head(child_list); e != NULL; e = list_item_next(e)) count++;
  return count;
}

PROCESS_THREAD(edcc_childreg_process, ev, data)
{
  static struct etimer periodic;
  (void)ev; (void)data;

  etimer_set(&periodic, EDCC_CHILDREG_KEEPALIVE_SEC * CLOCK_SECOND);

  while(1) {
    PROCESS_WAIT_EVENT_UNTIL(etimer_expired(&periodic));
    etimer_reset(&periodic);

    rpl_dag_t *dag = rpl_get_any_dag();
    if(dag == NULL || dag->preferred_parent == NULL) continue;

    uip_ipaddr_t parent_ip;
    uip_ipaddr_copy(&parent_ip, &dag->preferred_parent->addr);

    /* Detect parent changes: send leave to old, join to new */
    if(!have_last_parent || !uip_ipaddr_cmp(&parent_ip, &last_parent)) {
      if(have_last_parent) {
        send_msg(&last_parent, MSG_LEAVE);
      }
      send_msg(&parent_ip, MSG_JOIN);
      uip_ipaddr_copy(&last_parent, &parent_ip);
      have_last_parent = 1;
    } else {
      /* keepalive */
      send_msg(&parent_ip, MSG_JOIN);
    }

    purge_expired();
  }
  PROCESS_END();
}
