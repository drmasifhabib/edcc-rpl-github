\
#include "edcc-neighbor.h"
#include "sys/memb.h"
#include "sys/ctimer.h"
#include "lib/random.h"
#include "net/ipv6/uip-ds6-nbr.h"
#include <string.h>
#include <stdio.h>

#ifndef EDCC_NEIGHBOR_TABLE_SIZE
#define EDCC_NEIGHBOR_TABLE_SIZE 40
#endif

typedef struct {
  uip_ipaddr_t ipaddr;
  uint8_t child_count;
  uint8_t residual_energy_q8; /* 0..255 meaning 0..1 */
  uint16_t delay_samples[EDCC_DELAY_W];
  uint8_t delay_idx;
  uint8_t delay_count;
  uint32_t delay_sum_ms;
  uint32_t last_update_sec;
} edcc_nbr_info_t;

MEMB(edcc_memb, edcc_nbr_info_t, EDCC_NEIGHBOR_TABLE_SIZE);
LIST(edcc_list);

/* Normalization bounds for current parent-selection round */
static float etx_min, etx_max;
static float delay_min, delay_max;
static float cc_min, cc_max;
static float re_min, re_max;
static uint8_t bounds_inited;

static edcc_nbr_info_t *
find_or_alloc(const uip_ipaddr_t *ip)
{
  edcc_nbr_info_t *e;
  for(e = list_head(edcc_list); e != NULL; e = list_item_next(e)) {
    if(uip_ipaddr_cmp(&e->ipaddr, ip)) return e;
  }
  e = memb_alloc(&edcc_memb);
  if(e == NULL) {
    /* simple eviction: drop head */
    e = list_chop(edcc_list);
    if(e == NULL) return NULL;
  }
  memset(e, 0, sizeof(*e));
  uip_ipaddr_copy(&e->ipaddr, ip);
  e->child_count = 0;
  e->residual_energy_q8 = 255; /* assume full if unknown */
  list_add(edcc_list, e);
  return e;
}

void
edcc_neighbor_init(void)
{
  memb_init(&edcc_memb);
  list_init(edcc_list);
  bounds_inited = 0;
}

void
edcc_neighbor_update_from_dio(const uip_ipaddr_t *from,
                             uint8_t child_count,
                             uint8_t residual_energy_q8)
{
  edcc_nbr_info_t *e = find_or_alloc(from);
  if(!e) return;
  e->child_count = child_count;
  e->residual_energy_q8 = residual_energy_q8;
  e->last_update_sec = clock_seconds();
}

void
edcc_neighbor_delay_sample(const uip_ipaddr_t *nbr, uint16_t rtt_ms)
{
  edcc_nbr_info_t *e = find_or_alloc(nbr);
  if(!e) return;

  if(e->delay_count < EDCC_DELAY_W) {
    e->delay_samples[e->delay_idx] = rtt_ms;
    e->delay_sum_ms += rtt_ms;
    e->delay_count++;
    e->delay_idx = (e->delay_idx + 1) % EDCC_DELAY_W;
  } else {
    uint16_t old = e->delay_samples[e->delay_idx];
    e->delay_samples[e->delay_idx] = rtt_ms;
    e->delay_sum_ms = e->delay_sum_ms - old + rtt_ms;
    e->delay_idx = (e->delay_idx + 1) % EDCC_DELAY_W;
  }
}

float
edcc_neighbor_get_delay_ms(const uip_ipaddr_t *nbr)
{
  edcc_nbr_info_t *e;
  for(e = list_head(edcc_list); e != NULL; e = list_item_next(e)) {
    if(uip_ipaddr_cmp(&e->ipaddr, nbr)) {
      if(e->delay_count == 0) return 1000.0f; /* default unknown */
      return (float)e->delay_sum_ms / (float)e->delay_count;
    }
  }
  return 1000.0f;
}

uint8_t
edcc_neighbor_get_child_count(const uip_ipaddr_t *nbr)
{
  edcc_nbr_info_t *e;
  for(e = list_head(edcc_list); e != NULL; e = list_item_next(e)) {
    if(uip_ipaddr_cmp(&e->ipaddr, nbr)) return e->child_count;
  }
  return 0;
}

float
edcc_neighbor_get_residual_energy(const uip_ipaddr_t *nbr)
{
  edcc_nbr_info_t *e;
  for(e = list_head(edcc_list); e != NULL; e = list_item_next(e)) {
    if(uip_ipaddr_cmp(&e->ipaddr, nbr)) return ((float)e->residual_energy_q8) / 255.0f;
  }
  return 1.0f;
}

/* --- Normalization for comparability across neighbors (min-max into [0,1]) --- */
void
edcc_neighbor_normalization_begin(void)
{
  bounds_inited = 0;
}

static void
observe_bound(float v, float *mn, float *mx)
{
  if(!bounds_inited) {
    *mn = *mx = v;
    return;
  }
  if(v < *mn) *mn = v;
  if(v > *mx) *mx = v;
}

void
edcc_neighbor_normalization_observe(const uip_ipaddr_t *nbr,
                                   float etx, float delay_ms,
                                   float cc_penalized, float residual_energy)
{
  (void)nbr;
  if(!bounds_inited) {
    etx_min = etx_max = etx;
    delay_min = delay_max = delay_ms;
    cc_min = cc_max = cc_penalized;
    re_min = re_max = residual_energy;
    bounds_inited = 1;
  } else {
    observe_bound(etx, &etx_min, &etx_max);
    observe_bound(delay_ms, &delay_min, &delay_max);
    observe_bound(cc_penalized, &cc_min, &cc_max);
    observe_bound(residual_energy, &re_min, &re_max);
  }
}

void
edcc_neighbor_normalization_end(void)
{
  /* nothing; bounds already set */
}

static float
norm_minmax(float v, float mn, float mx)
{
  if(mx - mn < 1e-6f) return 0.0f;
  float n = (v - mn) / (mx - mn);
  if(n < 0.0f) n = 0.0f;
  if(n > 1.0f) n = 1.0f;
  return n;
}

/* smaller is better for ETX/delay/cc_penalized, so normalized value is [0,1] where 0 is best */
float edcc_norm_etx(float etx) { return norm_minmax(etx, etx_min, etx_max); }
float edcc_norm_delay(float d) { return norm_minmax(d, delay_min, delay_max); }
float edcc_norm_cc(float cc) { return norm_minmax(cc, cc_min, cc_max); }

/* residual energy: higher is better -> convert to penalty (1 - normalized energy) */
float
edcc_norm_energy_penalty(float residual_energy)
{
  float n = norm_minmax(residual_energy, re_min, re_max); /* 0 low ... 1 high */
  return 1.0f - n;
}
