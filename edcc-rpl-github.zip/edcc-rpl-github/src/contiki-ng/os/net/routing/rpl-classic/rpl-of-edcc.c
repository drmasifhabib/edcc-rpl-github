\
#include "rpl-of-edcc.h"
#include "edcc-neighbor.h"
#include "net/ipv6/uip-ds6-nbr.h"
#include "net/link-stats.h"
#include "sys/log.h"
#include <stdio.h>
#include <string.h>

#define LOG_MODULE "EDCC-OF"
#define LOG_LEVEL LOG_LEVEL_INFO

/* ---- Utility: read ETX from link-stats (Contiki-NG stores ETX in link stats as an integer) ---- */
static float
get_etx(const linkaddr_t *lladdr)
{
  const struct link_stats *s = link_stats_from_lladdr(lladdr);
  if(s == NULL) {
    return 10.0f; /* unknown */
  }

  /* In Contiki-NG, ETX is often stored as "etx" scaled by LINK_STATS_ETX_DIVISOR (usually 128).
   * If that symbol is not defined in your tree, adjust accordingly.
   */
#ifdef LINK_STATS_ETX_DIVISOR
  return (float)s->etx / (float)LINK_STATS_ETX_DIVISOR;
#else
  return (float)s->etx / 128.0f;
#endif
}

/* penalty for overloaded parents (Eq. 6 concept) */
static float
child_count_penalized(uint8_t cc)
{
  if(cc <= EDCC_TAU_CC) return (float)cc;
  return (float)cc + EDCC_LAMBDA_CC * (float)(cc - EDCC_TAU_CC);
}

uint8_t
edcc_get_advertised_child_count(const rpl_parent_t *p)
{
  if(p == NULL) return 0;
  return edcc_neighbor_get_child_count(&p->addr);
}

float
edcc_get_advertised_residual_energy(const rpl_parent_t *p)
{
  if(p == NULL) return 1.0f;
  return edcc_neighbor_get_residual_energy(&p->addr);
}

float
edcc_get_delay_estimate_norm(const rpl_parent_t *p)
{
  if(p == NULL) return 1.0f;
  return edcc_neighbor_get_delay_ms(&p->addr);
}

static float
edcc_metric_of_parent(const rpl_parent_t *p)
{
  if(p == NULL) return 1e9f;

  /* raw values */
  float etx = get_etx(rpl_get_parent_lladdr(p));
  float delay_ms = edcc_neighbor_get_delay_ms(&p->addr);
  uint8_t cc = edcc_neighbor_get_child_count(&p->addr);
  float cc_p = child_count_penalized(cc);
  float re = edcc_neighbor_get_residual_energy(&p->addr);

  /* normalized values */
  float etx_n = edcc_norm_etx(etx);
  float delay_n = edcc_norm_delay(delay_ms);
  float cc_n = edcc_norm_cc(cc_p);
  float e_pen = edcc_norm_energy_penalty(re);

  float m = EDCC_ALPHA1 * etx_n + EDCC_ALPHA2 * cc_n + EDCC_ALPHA3 * delay_n + EDCC_ALPHA4 * e_pen;
  return m;
}

/* --- OF API hooks (RPL Classic) --- */
static void
reset(rpl_dag_t *dag)
{
  (void)dag;
  edcc_neighbor_init();
}

static uint16_t
parent_link_metric(rpl_parent_t *p)
{
  /* used by RPL core for rank calculations in some paths */
  if(p == NULL) return 0xffff;
  float etx = get_etx(rpl_get_parent_lladdr(p));
  uint16_t scaled = (uint16_t)(etx * 256.0f); /* arbitrary scaling */
  return scaled;
}

/* Rank increase: keep compatible with MRHOF-style ETX accumulation, but EDCC affects parent selection */
static uint16_t
parent_rank_increase(rpl_parent_t *p)
{
  if(p == NULL) return INFINITE_RANK;

  /* Base increase proportional to ETX */
  float etx = get_etx(rpl_get_parent_lladdr(p));
  uint16_t inc = (uint16_t)(RPL_MIN_HOPRANKINC * etx);
  if(inc < RPL_MIN_HOPRANKINC) inc = RPL_MIN_HOPRANKINC;
  return inc;
}

static rpl_parent_t *
best_parent(rpl_parent_t *p1, rpl_parent_t *p2)
{
  if(p1 == NULL) return p2;
  if(p2 == NULL) return p1;

  /* Collect bounds across both candidates for normalization */
  edcc_neighbor_normalization_begin();

  float etx1 = get_etx(rpl_get_parent_lladdr(p1));
  float d1 = edcc_neighbor_get_delay_ms(&p1->addr);
  float cc1p = child_count_penalized(edcc_neighbor_get_child_count(&p1->addr));
  float re1 = edcc_neighbor_get_residual_energy(&p1->addr);

  float etx2 = get_etx(rpl_get_parent_lladdr(p2));
  float d2 = edcc_neighbor_get_delay_ms(&p2->addr);
  float cc2p = child_count_penalized(edcc_neighbor_get_child_count(&p2->addr));
  float re2 = edcc_neighbor_get_residual_energy(&p2->addr);

  edcc_neighbor_normalization_observe(&p1->addr, etx1, d1, cc1p, re1);
  edcc_neighbor_normalization_observe(&p2->addr, etx2, d2, cc2p, re2);
  edcc_neighbor_normalization_end();

  float m1 = edcc_metric_of_parent(p1);
  float m2 = edcc_metric_of_parent(p2);

  /* Hysteresis (θ): keep current parent unless the alternative is sufficiently better */
  rpl_parent_t *current = p1;
  rpl_parent_t *cand = p2;

  /* If p1 is current preferred, apply hysteresis; otherwise choose min */
  if(current == rpl_get_parent(p1->dag->preferred_parent)) {
    if(m2 + EDCC_THETA < m1) return cand;
    return current;
  } else if(cand == rpl_get_parent(p2->dag->preferred_parent)) {
    if(m1 + EDCC_THETA < m2) return current;
    return cand;
  }

  /* otherwise simply pick best metric */
  return (m1 <= m2) ? p1 : p2;
}

static rpl_rank_t
calculate_rank(rpl_parent_t *p, rpl_rank_t base_rank)
{
  if(p == NULL) return INFINITE_RANK;
  if(base_rank == 0) base_rank = p->dag->rank;

  rpl_rank_t new_rank = base_rank + parent_rank_increase(p);
  if(new_rank < base_rank) return INFINITE_RANK;
  return new_rank;
}

/* Metric container: EDCC option is produced by each node to advertise its current child count and residual energy.
 * Parsing/writing is done by patches in rpl-icmp6.c (see patches/).
 */
static void
update_metric_container(rpl_dag_t *dag)
{
  (void)dag;
  /* handled in patched rpl-icmp6.c via edcc_mc_write() */
}

rpl_of_t rpl_of_edcc = {
  .reset = reset,
  .parent_link_metric = parent_link_metric,
  .parent_rank_increase = parent_rank_increase,
  .best_parent = best_parent,
  .calculate_rank = calculate_rank,
  .update_metric_container = update_metric_container,
};
