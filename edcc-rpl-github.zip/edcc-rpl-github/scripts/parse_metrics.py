\
#!/usr/bin/env python3
import argparse, re, csv, pathlib

TX_RE = re.compile(r'EDCC-NODE.*TX seq=(\d+)')
RX_RE = re.compile(r'EDCC-SINK.*RX from .*: (\d+) bytes')
RE_RE = re.compile(r'EDCC-NODE.*RE=([0-9.]+)')
CHURN_RE = re.compile(r'parent', re.IGNORECASE)  # adjust to match your RPL logs

def parse_one(path: pathlib.Path):
    tx = 0
    rx = 0
    re_last = []
    churn = 0
    with path.open('r', errors='ignore') as f:
        for line in f:
            if 'EDCC-NODE' in line and 'TX seq=' in line:
                tx += 1
                m = RE_RE.search(line)
                if m:
                    re_last.append(float(m.group(1)))
            if 'EDCC-SINK' in line and 'RX from' in line:
                rx += 1
            if CHURN_RE.search(line) and 'preferred parent' in line.lower():
                churn += 1
    pdr = (rx / tx) if tx else 0.0
    avg_re = (sum(re_last)/len(re_last)) if re_last else 0.0
    return dict(file=str(path), tx=tx, rx=rx, pdr=pdr, churn=churn, avg_residual_energy=avg_re)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('logs', nargs='+', help='log files')
    ap.add_argument('--out', default='metrics.csv')
    args = ap.parse_args()

    rows = [parse_one(pathlib.Path(p)) for p in args.logs]
    with open(args.out, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys())
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"Wrote {args.out} with {len(rows)} rows")

if __name__ == '__main__':
    main()
